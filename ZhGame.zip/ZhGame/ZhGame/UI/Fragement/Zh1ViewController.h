//
//  Zh1ViewController.h
//  LearnDemo
//
//  Created by zhouhuan on 16/3/5.
//  Copyright © 2016年 zhouhuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Zh1ViewController : UIViewController

@property (nonatomic,strong)UITableView *backTableView;
@property (nonatomic,strong)UIImageView *secondTableView;



@end

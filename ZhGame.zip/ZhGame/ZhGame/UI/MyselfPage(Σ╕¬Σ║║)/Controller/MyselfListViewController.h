//
//  MyselfListViewController.h
//  AMomentDemo
//
//  Created by lanou3g on 15/12/17.
//  Copyright © 2015年 syx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZhLoginViewController.h"

@interface MyselfListViewController : UIViewController<ZhLoginDelegate>

@end
